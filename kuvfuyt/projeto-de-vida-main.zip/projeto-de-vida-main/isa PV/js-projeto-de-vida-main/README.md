
### Acesse o [Figma](https://www.figma.com/community/file/1266748897061926443/Prot%C3%B3tipo---Javascript%3A-organizando-seu-projeto-de-vida-com-matem%C3%A1tica-aplicada) para ter acesso ao protótipo


![Alura Start-Javascript_ organizando seu projeto de vida com matemática aplicada](https://github.com/marcelopaludetto/js-projeto/assets/78444171/079f241f-8121-477e-b64c-a5251c2e306d)
